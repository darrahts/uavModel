  function X = SQRT(x)
    X = sqrt(max(0,x));
  end